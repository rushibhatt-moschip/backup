#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>

/* Needed by all modules */
/* Needed for KERN_INFO */
/* Needed for the macros */

MODULE_LICENSE("GPL");	

int my_init(void)
{
	printk(KERN_INFO "This is my custom made init module\n");
	return 0;
}

void my_deinit(void){
	printk(KERN_INFO "This is my de initialization function\n");
}

module_init(my_init);
module_exit(my_deinit);

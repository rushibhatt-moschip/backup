#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/fs.h>

#define NUM_DEVICES 3
#define DEVICE_NAME "Character_Device_Driver"

MODULE_AUTHOR("Devashree Katarkar");
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Character device module");

static dev_t dev;

static int __init chardev_init(void){
	
	int ret_val =0;
	ret_val = alloc_chrdev_region(&dev,0,NUM_DEVICES, DEVICE_NAME);
	
	if(ret_val < 0){
		printk(KERN_ERR "Allocation for character device driver failed - %d\n", ret_val);
		return -1;
	}
		printk(KERN_INFO "Allocation successful\n");
		printk(KERN_INFO "Major number: %d\n",MAJOR(dev));
		printk(KERN_INFO "Module loaded successfully\n");
		return 0;
}

static void __exit chardev_exit(void){
	
	unregister_chrdev_region(dev,NUM_DEVICES);
	printk(KERN_INFO "Module unloaded successfully\n");

}

module_init(chardev_init);
module_exit(chardev_exit);


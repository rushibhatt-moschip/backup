#include <linux/module.h>
#include <linux/kernel.h>

MODULE_LICENSE("GPL");

int __init part_one_init(void){
	printk(KERN_DEBUG "Spilt iniliatization\n");
	return 0;
}

module_init(part_one_init);

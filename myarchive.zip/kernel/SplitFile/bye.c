#include <linux/module.h>
#include <linux/kernel.h>

MODULE_LICENSE("GPL");

void __exit part_one_deinit(void){
	printk(KERN_DEBUG "Spilt deiniliatization\n");
	
}

module_exit(part_one_deinit);

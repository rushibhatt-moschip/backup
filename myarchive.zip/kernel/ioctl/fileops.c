#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/kdev_t.h>
#include <linux/fs.h>
#include <asm/uaccess.h>
#include <linux/cdev.h>
#include <linux/ioctl.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Devashree katarkar");
MODULE_DESCRIPTION("FILE OPERATIONS MODULE");

#define DEVICE_NAME "FILEOPS"
#define NUM_DEVICES 1
#define BUF_LEN 24
#define WR_VAL _IOW('a', 'a', int32_t *)
#define RD_VAL _IOR('a', 'b', int32_t *)

static int chardev_open(struct inode *, struct file *);
static int chardev_close(struct inode *, struct file *);
static ssize_t chardev_read(struct file *, char *, size_t, loff_t *);
static ssize_t chardev_write(struct file *, const char *, size_t, loff_t *);
static long etx_ioctl(struct file *, unsigned int , unsigned long );
/*
 * dev_stat - informs about the activity of the device,i.e, open or close
 * dev - 
 * msg - 
 * msg_ptr -
 * temp_cdev - */

static int dev_stat = 0;
static dev_t dev;
static char msg[BUF_LEN] = {'\0'};
static char *msg_ptr = NULL;
static struct cdev* temp_cdev = NULL;
int32_t value = 0;	
static struct file_operations fops = {
	.owner = THIS_MODULE,
	.read = chardev_read,
	.write = chardev_write,
	.open = chardev_open,
	.unlocked_ioctl = etx_ioctl,
	.release =chardev_close,

};


static int __init ch_init(void){
	int ret = 0;
	ret = alloc_chrdev_region(&dev, 0, NUM_DEVICES, DEVICE_NAME);
	if(ret < 0)
	{
		printk(KERN_ERR "alloc_chrdev_region failed with error - %d\n", ret);
		return -1;
	}
	temp_cdev = cdev_alloc();
	if(temp_cdev == NULL)
	{
		printk(KERN_ERR "cdev_alloc failed\n");
		return -1;
	}
	temp_cdev->owner = THIS_MODULE;
	temp_cdev->ops = &fops;
	ret = cdev_add(temp_cdev, dev, NUM_DEVICES);
	if(ret < 0)
	{
		printk(KERN_ERR "cdev_add failed with error - %d\n", ret);
		return -1;
	}
	printk(KERN_INFO "I was assigned major number %d. To talk to\n", MAJOR(dev));
	printk(KERN_INFO "the driver, create a dev file with\n");
	printk(KERN_INFO "'mknod /dev/%s c %d 0'.\n", DEVICE_NAME, MAJOR(dev));
	printk(KERN_INFO "Try various minor numbers. Try to cat and echo to\n");
	printk(KERN_INFO "the device file.\n");

	return 0;
}

static void __exit ch_deinit(void)
{
	printk(KERN_INFO "Cleaning up device...\n");
	cdev_del(temp_cdev);
	unregister_chrdev_region(dev, NUM_DEVICES);
	printk(KERN_INFO "Device cleanup done\n");
	printk(KERN_INFO "Now please delete the device file /dev/%s\n",DEVICE_NAME);
}

static int chardev_open(struct inode *inode, struct file *file)
{
	static unsigned int counter = 1;
	if (dev_stat)
	{
		printk(KERN_WARNING "Device is already in use...try again!!!\n");
		return -EBUSY;
	}
	dev_stat = 1;
	printk(KERN_DEBUG "%s device opened\n", DEVICE_NAME);
	sprintf(msg, "Hello world : %d\n", counter++);
	msg_ptr = msg;
	return 0;
}

static int chardev_close(struct inode *inode, struct file *file)
{
	dev_stat = 0;
	/* We're now ready for our next caller */
	printk(KERN_DEBUG "%s device released\n", DEVICE_NAME);
	return 0;
}


static ssize_t chardev_read(struct file* filp,char __user* buffer,size_t length,loff_t* offset)
{
	/*
	 * Number of bytes actually written to the buffer
	 */
	int bytes_read = 0;
	while(*msg_ptr && length)
	{
		/*
		 * The buffer is in the user data segment, not the kernel
		 * segment so "*" assignment won't work. We have to use
		 * put_user which copies data from the kernel data segment to
		 * the user data segment.
		 */
		if((put_user(*(msg_ptr++), buffer++)) != 0)
		{
			printk(KERN_ERR "%s: read data failed\n", __func__);
			return -EFAULT;
		}
		length--;
		bytes_read++;
	}
	return bytes_read;
}

static ssize_t chardev_write(struct file *filp, const char *buff, size_t len,loff_t * off){
	printk(KERN_ALERT "Sorry, this operation isn't supported.\n");
	return -EINVAL;
}
static long etx_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
	switch(cmd) {
		case WR_VAL:
			if(copy_from_user(&value, (int32_t*) arg, sizeof(value)) == 0) {
				printk(KERN_INFO "Value = %d\n", value);
			}
			else {
				printk(KERN_ERR "copy_from_user failed\n");
			}
			break;
		case RD_VAL:
			if(copy_to_user((int32_t*) arg, &value, sizeof(value)) != 0) {
				printk(KERN_ERR "copy_to_user failed\n");
			}
			break;
	}
	return 0;
}

module_init(ch_init);
module_exit(ch_deinit);

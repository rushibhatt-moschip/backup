/* module_spanning_exit.c : Illustration of multi-file modules */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>


MODULE_LICENSE("GPL");

void module_split_exit(void)
{
	printk(KERN_DEBUG "Remember! There is no exit once you entered!\n");
}
module_exit(module_split_exit);

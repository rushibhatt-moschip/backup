/* module_spanning_init.c : Illustration of multi-file modules */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>


MODULE_LICENSE("GPL");

int __init module_split_init(void)
{
	printk(KERN_DEBUG "Welcome to the universe of linux!\n");
	return 0;
}
module_init(module_split_init);

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/stat.h>
#include <linux/init.h>

static int age = 21;
module_param_named(chaitanya_age, age, int, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP);
MODULE_PARM_DESC(chaitanya_age, "age of chaitanya shrimankar"); 

static char* name = "chaitanya shrimankar";
module_param(name, charp, S_IRUSR | S_IRGRP | S_IROTH);
MODULE_PARM_DESC(name, "name of the person");

int __init cmdline_demo_init(void){
	
	printk(KERN_NOTICE "=> name of person is %s\n", name);
	printk(KERN_NOTICE "=> age of person is %d\n", age);
	
	return 0;
}

void __exit cmdline_demo_exit(void){
	printk(KERN_WARNING "----you now know the name and age---\n");
}

module_init(cmdline_demo_init);
module_exit(cmdline_demo_exit);
MODULE_AUTHOR("Chaitanya Shrimankar");
MODULE_LICENSE("GPL");


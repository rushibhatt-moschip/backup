/* The simplest kernel module */

#include <linux/module.h> /* Needed by all modules */
#include <linux/kernel.h> /* Needed for KERN_INFO */
#include <linux/init.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Chaitanya Shrimankar");
MODULE_DESCRIPTION("Tutorial module for Training");
MODULE_VERSION("1.0");
MODULE_ALIAS("sample module");

static int __init insmod_func(void)
{
	printk(KERN_INFO "Pav bhaji, pulao, samosa chaat, papdi chaat, masala papad\n");
	return 0;
}
static void __exit rmmod_func(void)
{
	printk(KERN_INFO "There is no way to exit. see you again!\n");
}

module_init(insmod_func);
module_exit(rmmod_func);
